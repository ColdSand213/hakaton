package com.example.guidprofesi;

import androidx.fragment.app.Fragment;

public class MainFragment {
    public static Fragment newInstance() {

        return null;
    }
}
